# PACELINE

A responsive two-page running-shop website (Home + About) built for the DCS × GDG SASTRA Web Cluster frontend task. Plain HTML5, CSS3 and vanilla JavaScript — no frameworks, no build step.

## Features
- Home: announcement bar, sticky header, 3-slide hero (dot controls + arrow keys), category cards, filterable product grid (data-driven), wishlist hearts, story panel, explore tiles
- About: story hero, values, timeline, location, founders, CTA
- Cart starts with two demo items on first visit (so the header badge matches the design's "2"); after that it behaves normally and persists in localStorage
- Mobile menu, search dialog (products, pages, collections), cart drawer (persists across pages), toasts for pages that don't exist yet
- Newsletter form with client-side validation (success is simulated)

## Tech stack
HTML5 · CSS3 (custom properties, grid, flexbox) · JavaScript (classic deferred scripts) · self-hosted Inter font files (WOFF2 in `assets/fonts/`; no runtime dependency on any package or CDN) · Git

## Project structure
```
index.html, about.html   pages
css/    base (tokens, reset) · layout (header/footer) · components · home · about · responsive
js/     main.js (shared) · home.js · about.js · data/products.js
assets/ home/ about/ (WebP images) · fonts/ · favicon.svg
```

## Local setup
```bash
git clone <repo-url> && cd paceline
python3 -m http.server 8000     # (or: python -m http.server 8000)
# open http://localhost:8000
```
No build step is needed: open `index.html` directly, or serve the folder (e.g. the command above) for a closer match to production.

## Motion
Subtle, restrained transitions only: scroll fade-in on About cards, hover effects on buttons and cards, a sliding cart drawer and cross-fading hero slides. All animation is disabled under `prefers-reduced-motion`.

## Links
Every link goes somewhere: nav and category links jump to sections or apply a product filter (`index.html?f=sale#arrivals`), social links open the networks' home pages, and pages that don't exist in this demo (Careers, Privacy, ...) open a short info dialog instead of a dead link.

## Responsive breakpoints
Layout rules change at 1280, 1024, 900 (hamburger menu, stacked splits), 768, 600 and 480px.

## Accessibility
Semantic landmarks, skip link, labelled form field, `aria-live` feedback, `aria-expanded` menu, `aria-pressed` filters/hearts, native `<dialog>` for search and cart (focus trap, Escape), visible focus rings, `prefers-reduced-motion` support. Small orange text uses a darker orange (`#C2410C`) on cream for contrast.

## Performance
WebP images with explicit dimensions, `srcset` on large images, `loading="lazy"` below the fold, preloaded hero, `font-display: swap`, deferred classic scripts, no dependencies.

## Browser compatibility
- **Tested:** Chromium 141 only (automated Playwright run at 1440px and 375px on both pages, plus manual visual comparison against the design screenshots).
- **Not tested:** Firefox, Safari/WebKit, Edge. The code uses standard features only, but please check them manually.
- **Not performed:** Lighthouse, screen-reader testing, automated accessibility scoring (e.g. axe).

## Deployment
Static site, no build step.
- **Netlify:** Add new site → Import from Git → pick the repo → leave build command empty, publish directory `.` → Deploy.
- **Vercel:** Add New → Project → import the repo → Framework "Other", no build command → Deploy.

Live URL: _to be added after deployment._

## Known limitations
No backend, authentication, payments or mailing service. Only Home and About are designed; other links show a "coming soon" toast. The shoe photo is reused for all products (one asset supplied). Address and hours on About are not provided in the design, so none are shown.
