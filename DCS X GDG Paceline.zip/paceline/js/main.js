// Shared behaviour for every page: menu, toast, search, cart, newsletter, reveal.
(function () {
const products = window.PRODUCTS;

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

/* Safe localStorage wrapper (storage can be blocked in private modes) */
const store = {
  get(key, fallback) { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; } },
  set(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* ignore */ } },
};

/* Toast: a live region announces each message to screen readers */
function toast(message) {
  const el = Object.assign(document.createElement("p"), { className: "toast", textContent: message });
  $("#toasts").append(el);
  setTimeout(() => el.classList.add("out"), 2800);
  setTimeout(() => el.remove(), 3200);
}

/* Mobile menu */
const menuBtn = $("#menu-btn"), nav = $("#site-nav");
function setMenu(open) { nav.classList.toggle("open", open); menuBtn.setAttribute("aria-expanded", open); }
menuBtn.addEventListener("click", () => setMenu(!nav.classList.contains("open")));
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && nav.classList.contains("open")) { setMenu(false); menuBtn.focus(); } });
matchMedia("(min-width:901px)").addEventListener("change", () => setMenu(false));

/* Links to pages that don't exist yet show a toast instead */
document.addEventListener("click", (e) => {
  const soon = e.target.closest("[data-soon]");
  if (soon) { e.preventDefault(); toast(soon.dataset.soon); setMenu(false); soon.closest("dialog")?.close(); }
  const info = e.target.closest("[data-info]");
  if (info) { e.preventDefault(); openInfo(info.dataset.info); setMenu(false); }
  if (e.target.closest(".nav a, .nav button")) setMenu(false);
  const focus = e.target.closest("[data-focus]");
  if (focus) { e.preventDefault(); const t = $(focus.dataset.focus); t.scrollIntoView({ block: "center" }); t.focus({ preventScroll: true }); }
  const dlg = e.target.closest("[data-open]");
  if (dlg) { $(dlg.dataset.open).showModal(); $(dlg.dataset.open + " [data-autofocus]")?.focus(); }
  if (e.target.closest("[data-close]") || (e.target.matches("dialog") )) e.target.closest("dialog").close();
});
$("#account-btn").addEventListener("click", () => toast("Account features coming soon."));

/* Search: products + pages + collections */
const index = [
  ...products.map((p) => ({ label: `${p.brand} ${p.name}`, hint: "Product", href: "index.html#arrivals" })),
  { label: "Home", hint: "Page", href: "index.html" },
  { label: "About — Our Story", hint: "Page", href: "about.html" },
  { label: "Men", hint: "Collection", href: "index.html#explore" }, { label: "Women", hint: "Collection", href: "index.html#explore" },
  { label: "Footwear", hint: "Collection", href: "index.html?f=new#arrivals" }, { label: "Road Running", hint: "Collection", href: "index.html?f=new#arrivals" },
  { label: "Trail Running", hint: "Collection", href: "index.html?f=trail#arrivals" }, { label: "Sale", hint: "Collection", href: "index.html?f=sale#arrivals" },
  { label: "Apparel", hint: "Collection", href: "index.html#categories" }, { label: "Accessories", hint: "Collection", href: "index.html#categories" },
  { label: "Brands", hint: "Info", href: "index.html#arrivals", info: "brands" },
];
const input = $("#search-input"), results = $("#search-results");
// type="search" swallows Escape to clear itself, so close the dialog explicitly
input.addEventListener("keydown", (e) => { if (e.key === "Escape") { e.preventDefault(); input.closest("dialog").close(); } });
input.addEventListener("input", () => {
  const q = input.value.trim().toLowerCase();
  const hits = q ? index.filter((i) => i.label.toLowerCase().includes(q)) : [];
  results.innerHTML = hits.map((i) => `<li><a href="${i.href}" ${i.info ? `data-info="${i.info}"` : ""}>${i.label}<small>${i.hint}</small></a></li>`).join("");
  $("#search-status").textContent = !q ? "Type to search products, pages and collections." : hits.length ? `${hits.length} result${hits.length > 1 ? "s" : ""}` : `No results for “${input.value.trim()}”.`;
});

/* Cart (persisted so Home and About share it) */
// First visit: seed two demo items so the badge matches the design reference (2)
let cart = store.get("paceline-cart", [{ id: "cloudmonster-3", qty: 1 }, { id: "vaporfly-4", qty: 1 }]);
let rendered = false;
const money = (n) => `£${n}`;
function addToCart(id) {
  const line = cart.find((l) => l.id === id);
  line ? line.qty++ : cart.push({ id, qty: 1 });
  renderCart(); toast("Added to your bag.");
}
function renderCart() {
  store.set("paceline-cart", cart);
  const count = cart.reduce((n, l) => n + l.qty, 0);
  const badge = $("#cart-count"); badge.textContent = count; badge.hidden = !count;
  badge.classList.remove("bump"); void badge.offsetWidth; if (rendered) badge.classList.add("bump"); rendered = true;
  $("#cart-btn").setAttribute("aria-label", `Open bag, ${count} item${count === 1 ? "" : "s"}`);
  const lines = cart.map((l) => ({ ...l, p: products.find((p) => p.id === l.id) })).filter((l) => l.p);
  $("#cart-list").innerHTML = lines.length
    ? lines.map((l) => `<li class="cart-item"><img src="${l.p.image}" alt="" width="64" height="64"><div><strong>${l.p.brand} ${l.p.name}</strong><br>${money(l.p.price * l.qty)}<div class="qty"><button type="button" data-dec="${l.id}" aria-label="Decrease quantity of ${l.p.name}">−</button><span aria-live="polite">${l.qty}</span><button type="button" data-inc="${l.id}" aria-label="Increase quantity of ${l.p.name}">+</button></div></div><button type="button" data-remove="${l.id}" aria-label="Remove ${l.p.name}">Remove</button></li>`).join("")
    : `<li class="hint">Your bag is empty. Add a pair from New arrivals.</li>`;
  $("#cart-total").textContent = money(lines.reduce((n, l) => n + l.p.price * l.qty, 0));
}
$("#cart-list").addEventListener("click", (e) => {
  const b = e.target.closest("button"); if (!b) return;
  const kind = Object.keys(b.dataset)[0], id = b.dataset[kind];
  const line = cart.find((l) => l.id === id); if (!line) return;
  if (kind === "inc") line.qty++;
  if (kind === "dec") line.qty--;
  if (kind === "remove" || line.qty < 1) cart = cart.filter((l) => l !== line);
  renderCart();
  $(`#cart-list [data-${kind}="${id}"]`)?.focus(); // keep keyboard focus after the list re-renders
});
renderCart();

/* Newsletter validation (simulated success — no backend) */
$$(".nl-form").forEach((form) => {
  const field = $("input", form), msg = $(".nl-msg", form);
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const v = field.value.trim();
    const error = !v ? "Enter your email address." : !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) ? "That email doesn't look right. Check it and try again." : "";
    field.setAttribute("aria-invalid", !!error);
    msg.className = "nl-msg " + (error ? "err" : "ok");
    msg.textContent = error || "You're in. Check your inbox for 10% off your first order.";
    if (error) field.focus(); else form.reset();
  });
});


/* Info dialog: content for links that have no page of their own */
const INFO = {
  shipping: ["Shipping", "Free UK delivery on orders over £75."],
  returns: ["Returns", "30-day returns on every order."],
  brands: ["Brands", "We stock 40+ brands, including ON, Nike, Hoka and Asics — each one hand-picked by the team."],
  gait: ["Gait analysis", "Free gait analysis and injury consults run every Saturday at our Glasgow store, and they book out fast. Ask in store to reserve a slot."],
  range: ["Apparel & accessories", "This demo showcases the footwear range. Use New arrivals to browse the shoes."],
  accessibility: ["Accessibility", "Paceline supports keyboard navigation, a skip link, visible focus, screen-reader labels and reduced-motion preferences."],
};
function openInfo(key) {
  const [title, text] = INFO[key] ?? [key, `${key} isn't part of this demo site — it's a frontend showcase with no backend.`];
  $("#info-title").textContent = title; $("#info-body").innerHTML = `<p>${text}</p>`;
  $("#search").close(); $("#info").showModal();
}

/* Scroll reveal: flagged blocks fade in once as they enter the viewport */
const revealEls = $$("[data-reveal]");
if ("IntersectionObserver" in window) {
  const io = new IntersectionObserver((entries) => entries.forEach((en) => { if (en.isIntersecting) { en.target.classList.add("is-visible"); io.unobserve(en.target); } }), { threshold: 0.12 });
  revealEls.forEach((el) => io.observe(el));
} else revealEls.forEach((el) => el.classList.add("is-visible"));

window.Paceline = { $, $$, store, toast, addToCart };
})();
