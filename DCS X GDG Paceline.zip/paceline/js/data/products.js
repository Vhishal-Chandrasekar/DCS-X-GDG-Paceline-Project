// Product data from the supplied design. `tags` drive the filter pills.
window.PRODUCTS = [
  { id: "cloudmonster-3", brand: "ON", name: "Cloudmonster 3 — Hyper Lily", price: 210, badge: "new", tags: ["new", "best"] },
  { id: "vaporfly-4", brand: "Nike", name: "Vaporfly 4 — Volt Ice", price: 240, badge: "new", tags: ["new", "race"] },
  { id: "tecton-x-4", brand: "Hoka", name: "Tecton X 4 — Frost / Tangerine", price: 220, badge: "new", tags: ["new", "trail"] },
  { id: "megablast", brand: "Asics", name: "Megablast — White / Orange Glow", price: 210, badge: "sale", tags: ["new", "best", "race", "sale"] },
].map((p) => ({ ...p, image: "assets/home/product-shoe.webp" }));
