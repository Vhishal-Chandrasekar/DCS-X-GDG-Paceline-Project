// About page: stagger the timeline entries as they fade in.
(function () {
  const { $$ } = window.Paceline;
  $$(".timeline > li").forEach((li, i) => { li.style.transitionDelay = `${i * 90}ms`; });
})();
