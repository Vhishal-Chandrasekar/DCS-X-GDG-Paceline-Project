// Home page: hero slider, product grid, filters, wishlist.
(function () {
const products = window.PRODUCTS;
const { $, $$, store, addToCart } = window.Paceline;

/* Hero slider: buttons control which slide is visible */
const slides = $$(".slide"), dots = $$(".hero__dots button");
function showSlide(n) {
  const i = (n + slides.length) % slides.length;
  slides.forEach((s, k) => { s.classList.toggle("is-active", k === i); s.inert = k !== i; });
  dots.forEach((d, k) => d.setAttribute("aria-current", k === i));
  return i;
}
dots.forEach((d, k) => d.addEventListener("click", () => showSlide(k)));
$(".hero__dots").addEventListener("keydown", (e) => {
  const step = { ArrowRight: 1, ArrowLeft: -1 }[e.key]; if (!step) return;
  const cur = dots.findIndex((d) => d.getAttribute("aria-current") === "true");
  dots[showSlide(cur + step)].focus();
});
showSlide(0);

/* Products */
let wishlist = new Set(store.get("paceline-wishlist", []));
const grid = $("#product-grid");
const heart = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20.5s-8-4.9-8-11A4.5 4.5 0 0112 7a4.5 4.5 0 018 2.5c0 6.1-8 11-8 11z"/></svg>`;
function render(filter) {
  const list = products.filter((p) => p.tags.includes(filter));
  grid.innerHTML = list.map((p, i) => `
    <li class="product" style="--i:${i}">
      <div class="product__img">
        <img src="${p.image}" alt="${p.brand} ${p.name}" width="313" height="340" loading="lazy" decoding="async">
        ${p.badge ? `<span class="tag ${p.badge === "sale" ? "tag--sale" : ""}">${p.badge.toUpperCase()}</span>` : ""}
        <button class="heart" type="button" data-heart="${p.id}" aria-pressed="${wishlist.has(p.id)}" aria-label="Save ${p.brand} ${p.name} to wishlist">${heart}</button>
        <button class="add" type="button" data-add="${p.id}" aria-label="Add ${p.brand} ${p.name} to bag">Add to bag</button>
      </div>
      <div class="product__info"><p class="product__brand">${p.brand}</p><h3 class="product__name">${p.name}</h3><p class="product__price">£${p.price}</p></div>
    </li>`).join("") || `<li class="empty">Nothing here yet.</li>`;
  $("#product-status").textContent = `Showing ${list.length} product${list.length === 1 ? "" : "s"}`;
}
grid.addEventListener("click", (e) => {
  const h = e.target.closest("[data-heart]"), a = e.target.closest("[data-add]");
  if (h) {
    const id = h.dataset.heart;
    wishlist.has(id) ? wishlist.delete(id) : wishlist.add(id);
    h.classList.remove("pop"); void h.offsetWidth; h.classList.add("pop");
    h.setAttribute("aria-pressed", wishlist.has(id)); store.set("paceline-wishlist", [...wishlist]);
  }
  if (a) addToCart(a.dataset.add);
});
function setFilter(f, scroll) {
  $$(".pill").forEach((p) => p.setAttribute("aria-pressed", p.dataset.filter === f));
  render(f);
  if (scroll) { $("#arrivals").scrollIntoView({ behavior: "smooth" }); history.replaceState(null, "", `?f=${f}#arrivals`); }
}
$$(".pill").forEach((pill) => pill.addEventListener("click", () => setFilter(pill.dataset.filter)));
// Links such as "Sale" or "Trail Running" apply a filter in place on this page
document.addEventListener("click", (e) => {
  const link = e.target.closest("[data-filter-link]");
  if (link) { e.preventDefault(); setFilter(link.dataset.filterLink, true); }
});
const wanted = new URLSearchParams(location.search).get("f"); // e.g. index.html?f=sale from other pages
setFilter(["new", "best", "race", "trail", "sale"].includes(wanted) ? wanted : "new");
})();
